<template>

<div class="grid">

    <NewCardForm/>

    <CardsContainer/>

</div>


      
</template>

<script>
import NewCardForm from './components/NewCardForm.vue'
import CardsContainer from './components/CardsContainer.vue'


export default {
  components: {
    NewCardForm,
    CardsContainer,
    // eslint-disable-next-line
  },

}

</script>

<style lang='scss'>

.grid {
  display: flex;
  padding: 32px 32px 0;
  background: rgba(255, 254, 251, 0.8);
}

@media (max-width: 600px) {
  .grid {
    flex-direction: column;
    width: 100%;
  }
}


</style>
